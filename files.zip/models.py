# accounts/models.py
# ─────────────────────────────────────────────────────────────────────────────
# USER MODEL DESIGN
#
#  user_type     │ Login identifier │ Who they are
# ───────────────┼──────────────────┼──────────────────────────────────────────
#  parent        │ parent_id        │ Parent / guardian of enrolled students
#  teacher       │ username         │ Teaching staff
#  staff         │ username         │ Non-teaching staff (bursar, secretary…)
#  admin         │ username         │ School administrator / head teacher
#
# parent_id is auto-generated (PAR2025001) and stored on the User record.
# For parents, username is set equal to parent_id at creation time so
# Django's built-in ModelBackend works — no custom auth backend required.
#
# ParentProfile  — extended guardian information, linked to CustomUser
# StaffProfile   — covers both teachers and non-teaching staff
# ─────────────────────────────────────────────────────────────────────────────

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models


# ═══════════════════════════════════════════════════════════════════════════════
#  CHOICES
# ═══════════════════════════════════════════════════════════════════════════════

GENDER_CHOICES = [
    ('male',              'Male'),
    ('female',            'Female'),
    ('other',             'Other'),
    ('prefer_not_to_say', 'Prefer not to say'),
]

USER_TYPE_CHOICES = [
    ('parent',  'Parent / Guardian'),
    ('teacher', 'Teacher'),
    ('staff',   'Support Staff'),
    ('admin',   'Administrator'),
]


# ═══════════════════════════════════════════════════════════════════════════════
#  CUSTOM USER MANAGER
# ═══════════════════════════════════════════════════════════════════════════════

class CustomUserManager(BaseUserManager):

    def create_user(self, username, email=None, password=None, **extra_fields):
        if not username:
            raise ValueError('Username is required.')
        email = self.normalize_email(email) if email else ''
        user  = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_parent_user(self, parent_id: str, password=None, **extra_fields):
        """
        Create a parent account.
        username is set to parent_id so the standard login form works.
        """
        extra_fields['user_type'] = 'parent'
        extra_fields['parent_id'] = parent_id
        return self.create_user(
            username=parent_id,
            email=extra_fields.pop('email', ''),
            password=password,
            **extra_fields,
        )

    def create_superuser(self, username, email=None, password=None, **extra_fields):
        extra_fields.setdefault('is_staff',         True)
        extra_fields.setdefault('is_superuser',      True)
        extra_fields.setdefault('is_active',         True)
        extra_fields.setdefault('is_email_verified', True)
        extra_fields.setdefault('user_type',         'admin')
        return self.create_user(username, email, password, **extra_fields)


# ═══════════════════════════════════════════════════════════════════════════════
#  CUSTOM USER
# ═══════════════════════════════════════════════════════════════════════════════

class CustomUser(AbstractBaseUser, PermissionsMixin):
    """
    Central user account for every person in the system.

    Staff / Teacher / Admin  →  log in with  username  + password
    Parent / Guardian        →  log in with  parent_id + password
                                (username is set = parent_id at creation)
    """

    # ── Core auth ─────────────────────────────────────────────────────────────
    username         = models.CharField(max_length=50, unique=True)
    email            = models.EmailField(blank=True)

    # ── User type & parent identifier ─────────────────────────────────────────
    user_type        = models.CharField(
                           max_length=10,
                           choices=USER_TYPE_CHOICES,
                           default='staff',
                       )
    parent_id        = models.CharField(
                           max_length=20,
                           unique=True,
                           null=True,
                           blank=True,
                           help_text=(
                               'Auto-generated login ID for parents '
                               '(e.g. PAR20250001). Null for all non-parent types.'
                           ),
                       )

    # ── Personal details ──────────────────────────────────────────────────────
    first_name       = models.CharField(max_length=50)
    last_name        = models.CharField(max_length=50)
    other_names      = models.CharField(max_length=50, blank=True)
    gender           = models.CharField(max_length=20, choices=GENDER_CHOICES, blank=True)
    date_of_birth    = models.DateField(null=True, blank=True)
    profile_photo    = models.ImageField(upload_to='profiles/', blank=True, null=True)

    # ── Contact ───────────────────────────────────────────────────────────────
    phone            = models.CharField(max_length=15, blank=True)
    alt_phone        = models.CharField(max_length=15, blank=True)
    address          = models.TextField(blank=True)

    # ── Uganda-specific ───────────────────────────────────────────────────────
    nin              = models.CharField(
                           max_length=20,
                           blank=True,
                           verbose_name='National ID Number (NIN)',
                       )

    # ── Account flags ─────────────────────────────────────────────────────────
    is_active         = models.BooleanField(default=True)
    is_staff          = models.BooleanField(default=False)
    is_email_verified = models.BooleanField(default=False)

    # ── Timestamps ────────────────────────────────────────────────────────────
    date_joined      = models.DateTimeField(auto_now_add=True)
    updated_at       = models.DateTimeField(auto_now=True)

    objects          = CustomUserManager()

    USERNAME_FIELD   = 'username'
    REQUIRED_FIELDS  = ['first_name', 'last_name']

    class Meta:
        verbose_name        = 'User'
        verbose_name_plural = 'Users'
        ordering            = ['last_name', 'first_name']

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def full_name(self) -> str:
        parts = [self.first_name, self.other_names, self.last_name]
        return ' '.join(p for p in parts if p).strip()

    @property
    def is_parent_user(self) -> bool:
        return self.user_type == 'parent'

    @property
    def is_teacher_user(self) -> bool:
        return self.user_type == 'teacher'

    @property
    def is_support_staff_user(self) -> bool:
        return self.user_type == 'staff'

    @property
    def is_admin_user(self) -> bool:
        return self.user_type == 'admin'

    @property
    def login_identifier(self) -> str:
        """The credential this user presents at the login screen."""
        return self.parent_id if self.user_type == 'parent' else self.username

    def get_full_name(self) -> str:
        return self.full_name

    def get_short_name(self) -> str:
        return self.first_name

    def __str__(self) -> str:
        label = dict(USER_TYPE_CHOICES).get(self.user_type, self.user_type)
        return f'{self.full_name} ({label})'


# ═══════════════════════════════════════════════════════════════════════════════
#  PARENT PROFILE
# ═══════════════════════════════════════════════════════════════════════════════

class ParentProfile(models.Model):
    """
    Extended guardian / parent information.
    Linked 1-to-1 with a CustomUser whose user_type = 'parent'.

    The parent's login ID is user.parent_id  (e.g. PAR20250001).
    A single parent may be linked to multiple students via
    students.Student.parent (FK → this model).
    """

    RELATIONSHIP_CHOICES = [
        ('father',         'Father'),
        ('mother',         'Mother'),
        ('legal_guardian', 'Legal Guardian'),
        ('uncle',          'Uncle'),
        ('aunt',           'Aunt'),
        ('grandparent',    'Grandparent'),
        ('sibling',        'Elder Sibling'),
        ('other',          'Other'),
    ]

    # ── Link ──────────────────────────────────────────────────────────────────
    user             = models.OneToOneField(
                           CustomUser,
                           on_delete=models.CASCADE,
                           related_name='parent_profile',
                           limit_choices_to={'user_type': 'parent'},
                       )

    # ── Guardian details ──────────────────────────────────────────────────────
    relationship     = models.CharField(
                           max_length=20,
                           choices=RELATIONSHIP_CHOICES,
                       )
    occupation       = models.CharField(max_length=100, blank=True)
    employer         = models.CharField(max_length=200, blank=True)
    work_phone       = models.CharField(max_length=15, blank=True)
    work_address     = models.TextField(blank=True)

    # ── Uganda location ───────────────────────────────────────────────────────
    district         = models.CharField(max_length=100, blank=True)
    sub_county       = models.CharField(max_length=100, blank=True)
    village          = models.CharField(max_length=100, blank=True)
    religion         = models.CharField(max_length=50, blank=True)

    # ── Emergency contact ─────────────────────────────────────────────────────
    emergency_contact_name  = models.CharField(max_length=100, blank=True)
    emergency_contact_phone = models.CharField(max_length=15, blank=True)
    emergency_contact_rel   = models.CharField(
                                  max_length=50,
                                  blank=True,
                                  verbose_name='Emergency contact relationship',
                              )

    # ── Meta ──────────────────────────────────────────────────────────────────
    notes            = models.TextField(blank=True)
    is_active        = models.BooleanField(default=True)
    created_at       = models.DateTimeField(auto_now_add=True)
    updated_at       = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = 'Parent Profile'
        verbose_name_plural = 'Parent Profiles'
        ordering            = ['user__last_name', 'user__first_name']

    @property
    def parent_id(self) -> str:
        return self.user.parent_id or ''

    @property
    def full_name(self) -> str:
        return self.user.full_name

    @property
    def phone(self) -> str:
        return self.user.phone

    def __str__(self) -> str:
        return (
            f'{self.user.full_name} '
            f'({self.get_relationship_display()}) '
            f'[{self.parent_id}]'
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  STAFF PROFILE
# ═══════════════════════════════════════════════════════════════════════════════

class StaffProfile(models.Model):
    """
    Extended professional profile for teaching and non-teaching staff.
    Linked 1-to-1 with a CustomUser whose user_type = 'teacher', 'staff',
    or 'admin'.

    Login: username + password.

    Teaching staff  — has qualification, specialization, is_class_teacher,
                      class_managed, NSSF/TIN details.
    Support staff   — only employment fields are relevant; teaching fields
                      are left blank.
    """

    ROLE_CHOICES = [
        # Teaching
        ('head_teacher',    'Head Teacher'),
        ('deputy_head',     'Deputy Head Teacher'),
        ('teacher',         'Class Teacher'),
        ('subject_teacher', 'Subject Teacher'),
        # Non-teaching
        ('bursar',          'Bursar'),
        ('secretary',       'School Secretary'),
        ('librarian',       'Librarian'),
        ('lab_technician',  'Lab Technician'),
        ('nurse',           'School Nurse / Health Worker'),
        ('security',        'Security Personnel'),
        ('cleaner',         'Cleaner / Janitor'),
        ('driver',          'Driver'),
        ('cook',            'Cook / Catering Staff'),
        ('it_officer',      'IT Officer'),
        ('other',           'Other'),
    ]

    QUALIFICATION_CHOICES = [
        ('ptc',             'Primary Teachers Certificate (PTC)'),
        ('grade3',          'Grade III Certificate'),
        ('diploma',         'Diploma in Education'),
        ('degree',          'Bachelor of Education (B.Ed)'),
        ('pgde',            'PGDE'),
        ('masters',         'Masters in Education'),
        ('certificate',     'Certificate (Non-Education)'),
        ('diploma_other',   'Diploma (Non-Education)'),
        ('bachelors',       'Bachelors (Non-Education)'),
        ('none',            'No Formal Qualification'),
        ('other',           'Other'),
    ]

    EMPLOYMENT_TYPE_CHOICES = [
        ('permanent', 'Permanent'),
        ('contract',  'Contract'),
        ('part_time', 'Part-Time'),
        ('volunteer', 'Volunteer'),
        ('intern',    'Intern'),
    ]

    # ── Link ──────────────────────────────────────────────────────────────────
    user             = models.OneToOneField(
                           CustomUser,
                           on_delete=models.CASCADE,
                           related_name='staff_profile',
                           limit_choices_to={'user_type__in': ('teacher', 'staff', 'admin')},
                       )

    # ── Employment ────────────────────────────────────────────────────────────
    employee_id      = models.CharField(
                           max_length=20,
                           unique=True,
                           help_text='Auto-generated or assigned employee number '
                                     '(e.g. EMP20250001)',
                       )
    role             = models.CharField(max_length=20, choices=ROLE_CHOICES)
    employment_type  = models.CharField(
                           max_length=15,
                           choices=EMPLOYMENT_TYPE_CHOICES,
                           default='permanent',
                       )
    date_joined      = models.DateField()
    date_left        = models.DateField(null=True, blank=True)
    is_active        = models.BooleanField(default=True)

    # ── Teaching-specific (blank for non-teaching staff) ──────────────────────
    qualification    = models.CharField(
                           max_length=20,
                           choices=QUALIFICATION_CHOICES,
                           blank=True,
                       )
    specialization   = models.CharField(
                           max_length=100,
                           blank=True,
                           help_text='e.g. Mathematics, English, Early Childhood',
                       )
    is_class_teacher = models.BooleanField(
                           default=False,
                           help_text='Assigned as a class / form teacher?',
                       )
    class_managed    = models.ForeignKey(
                           'academics.SchoolClass',
                           on_delete=models.SET_NULL,
                           null=True,
                           blank=True,
                           related_name='form_teacher',
                           help_text='Class this teacher is directly responsible for',
                       )

    # ── Uganda payroll / HR ───────────────────────────────────────────────────
    nssf_number      = models.CharField(max_length=20, blank=True, verbose_name='NSSF Number')
    tin_number       = models.CharField(max_length=20, blank=True, verbose_name='TIN Number')
    salary_scale     = models.CharField(max_length=50, blank=True)
    bank_name        = models.CharField(max_length=100, blank=True)
    bank_account     = models.CharField(max_length=30, blank=True)

    # ── Profile ───────────────────────────────────────────────────────────────
    bio              = models.TextField(blank=True)
    notes            = models.TextField(blank=True,
                           help_text='Internal HR notes — not visible to the employee')
    signature        = models.ImageField(
                           upload_to='staff/signatures/',
                           blank=True,
                           null=True,
                           help_text='Used on report cards and official letters',
                       )

    # ── Timestamps ────────────────────────────────────────────────────────────
    created_at       = models.DateTimeField(auto_now_add=True)
    updated_at       = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = 'Staff Profile'
        verbose_name_plural = 'Staff Profiles'
        ordering            = ['user__last_name', 'user__first_name']

    @property
    def full_name(self) -> str:
        return self.user.full_name

    @property
    def is_teaching_staff(self) -> bool:
        return self.user.user_type == 'teacher'

    @property
    def is_non_teaching_staff(self) -> bool:
        return self.user.user_type == 'staff'

    def __str__(self) -> str:
        return (
            f'{self.employee_id} — {self.user.full_name} '
            f'({self.get_role_display()})'
        )
